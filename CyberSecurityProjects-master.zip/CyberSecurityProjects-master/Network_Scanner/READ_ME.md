NETWORK SCANNER
-----------------------------------------------------------------------------------------------------------------------
Created a Network_Scanner program using pythons scapy module

-Rather then using builtin functions, utilized scapy to scan local networks to collect and store ips and mac addresses
-Created packets and utlized program to ask the different networks to access it

------------------------------------------------------------------------------------------------------------------------
-Scapy is a packet manipulation tool for computer networks.

-It can forge or decode packets, send them on the wire, capture them, and match requests and replies.

-It can also handle tasks like scanning, tracerouting, probing, unit tests, attacks, and network discovery.
------------------------------------------------------------------------------------------------------------------------
USED ARGUMENT PARSER:
-allows for easy calls and user input through linux terminal on dabien products (i.e. Kali)
---

# Disclaimer
**Notice**

    This program is run on my own virtual box machines and set up. The code in this project can be and should be editied to fit your ip and mac address specifications. Ideal set up is necessary for proper efficeny.
---
***WARNING***

THIS CODE IS NOT USED FOR MALLICIOUS INTENT AND IS AN EDUCATIONAL PROJECT USED TO SHOWCASE MY ABILITIES AS A ETHICAL HACKER.
IF THIS CODE IS UTILIZED IN ANY FORM OF MALLICIOUS INTENT, BE INFORMED THAT PROPER LEAGAL COURSE OF ACTION CAN BE TAKEN ON THOSE WHO
USE IT BY LAW ENFORCEMENT AGENCIES.
